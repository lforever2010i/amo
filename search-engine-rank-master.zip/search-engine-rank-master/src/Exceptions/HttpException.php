<?php

namespace Tim168\SearchEngineRank\Exceptions;


class HttpException extends Exception
{

}