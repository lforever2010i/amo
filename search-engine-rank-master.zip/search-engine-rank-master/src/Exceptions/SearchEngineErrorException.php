<?php

namespace Tim168\SearchEngineRank\Exceptions;


class SearchEngineErrorException extends Exception
{

}