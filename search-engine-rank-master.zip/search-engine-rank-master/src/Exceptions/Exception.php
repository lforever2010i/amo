<?php

namespace Tim168\SearchEngineRank\Exceptions;


class Exception extends \Exception
{

}