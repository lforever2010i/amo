<?php

namespace Tim168\SearchEngineRank\Exceptions;


class InvalidArgumentException extends Exception
{

}